# -*- coding: utf-8 -*-
import math
from datetime import datetime, timezone

def sunpos_az_alt(dt_utc, lat_deg, lon_deg):
    """
    Grob vereinfachte Sonnenstandsberechnung (NOAA-ähnlich).
    Liefert Azimut (°, 0=Norden, CW) und Höhe (°).
    dt_utc: datetime in UTC
    """
    # Julian day
    epoch = datetime(2000,1,1,12,tzinfo=timezone.utc)
    delta = (dt_utc - epoch).total_seconds() / 86400.0
    # Meeus: mean anomaly, ecliptic longitude
    g = math.radians((357.529 + 0.98560028*delta) % 360.0)
    q = (280.459 + 0.98564736*delta) % 360.0
    L = math.radians((q + 1.915*math.sin(g) + 0.020*math.sin(2*g)) % 360.0)
    # Obliquity
    e = math.radians(23.439 - 0.00000036*delta)
    # RA/Dec
    X = math.cos(L)
    Y = math.cos(e)*math.sin(L)
    Z = math.sin(e)*math.sin(L)
    RA = math.atan2(Y, X)
    dec = math.asin(Z)
    # GMST
    GMST = (18.697374558 + 24.06570982441908 * delta) % 24.0
    # Local Sidereal Time
    LST = math.radians((GMST*15.0 + lon_deg) % 360.0)
    # Hour angle
    H = LST - RA
    lat = math.radians(lat_deg)
    # Altitude
    alt = math.asin(math.sin(lat)*math.sin(dec) + math.cos(lat)*math.cos(dec)*math.cos(H))
    # Azimuth (0=N, clockwise)
    az = math.atan2(math.sin(H), math.cos(H)*math.sin(lat) - math.tan(dec)*math.cos(lat))
    az_deg = (math.degrees(az) + 360.0) % 360.0
    alt_deg = math.degrees(alt)
    return az_deg, alt_deg
