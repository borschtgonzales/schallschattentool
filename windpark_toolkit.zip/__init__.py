# -*- coding: utf-8 -*-
from .plugin import WindparkToolkitPlugin

def classFactory(iface):
    return WindparkToolkitPlugin(iface)
