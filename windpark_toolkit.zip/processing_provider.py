# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from .algorithms.noise_raster import NoiseRasterAlgorithm
from .algorithms.shadow_raster import ShadowRasterAlgorithm

class WPTProvider(QgsProcessingProvider):
    def id(self):
        return "wpt"

    def name(self):
        return "Windpark Toolkit"

    def longName(self):
        return "Windpark Toolkit (WEA Schall & Schatten)"

    def loadAlgorithms(self):
        self.addAlgorithm(NoiseRasterAlgorithm())
        self.addAlgorithm(ShadowRasterAlgorithm())
