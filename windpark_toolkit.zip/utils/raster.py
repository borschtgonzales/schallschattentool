# -*- coding: utf-8 -*-
import numpy as np
from osgeo import gdal, osr

def open_dataset(path):
    ds = gdal.Open(path, gdal.GA_ReadOnly)
    if ds is None:
        raise RuntimeError(f"Cannot open raster: {path}")
    return ds

def read_array(ds, band=1):
    rb = ds.GetRasterBand(band)
    arr = rb.ReadAsArray().astype(np.float32)
    nd = rb.GetNoDataValue()
    return arr, nd

def geo_grid(ds):
    gt = ds.GetGeoTransform()
    cols = ds.RasterXSize
    rows = ds.RasterYSize
    xs = gt[0] + (np.arange(cols) + 0.5) * gt[1] + (np.arange(cols) + 0.5) * gt[2]*0
    ys = gt[3] + (np.arange(rows) + 0.5) * gt[5] + (np.arange(rows) + 0.5) * gt[4]*0
    X, Y = np.meshgrid(xs, ys)
    return X, Y, gt, cols, rows

def write_like(ds_ref, array, out_path, nodata=None, dtype=gdal.GDT_Float32):
    driver = gdal.GetDriverByName('GTiff')
    cols = ds_ref.RasterXSize
    rows = ds_ref.RasterYSize
    out_ds = driver.Create(out_path, cols, rows, 1, dtype, options=['COMPRESS=LZW'])
    out_ds.SetGeoTransform(ds_ref.GetGeoTransform())
    out_ds.SetProjection(ds_ref.GetProjection())
    band = out_ds.GetRasterBand(1)
    if nodata is not None:
        band.SetNoDataValue(nodata)
    band.WriteArray(array)
    band.FlushCache()
    out_ds.FlushCache()
    out_ds = None
    return out_path
