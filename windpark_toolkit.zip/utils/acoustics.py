# -*- coding: utf-8 -*-
import numpy as np

def level_from_point_source(LwA_dB, r_m, alpha_db_per_km=1.0):
    """
    Sehr vereinfachtes Freifeldmodell (nur für Demo):
      Lp = LwA - (A_div + A_atm)
      A_div = 20*log10(r) + 11
      A_atm = alpha [dB/km] * r[km]
    r_m: Entfernung in Metern (numpy array)
    """
    r = np.maximum(r_m, 1.0)
    A_div = 20.0 * np.log10(r) + 11.0
    A_atm = (alpha_db_per_km/1000.0) * r
    Lp = LwA_dB - (A_div + A_atm)
    return Lp

def energetic_sum(levels_db_stack):
    """Addiert Pegel (dB) energetisch über Achse 0."""
    lin = 10.0**(levels_db_stack/10.0)
    total = 10.0 * np.log10(np.sum(lin, axis=0))
    return total
